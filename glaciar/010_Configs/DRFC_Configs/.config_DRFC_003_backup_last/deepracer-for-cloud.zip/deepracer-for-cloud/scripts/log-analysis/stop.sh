#!/usr/bin/env bash

docker stop deepracer-analysis
