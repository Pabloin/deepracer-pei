#!/bin/bash

python3 menu.py